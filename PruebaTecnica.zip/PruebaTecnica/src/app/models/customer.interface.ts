export interface CustomerI {
    nombre: string;
    cant: string;
    precio: string;
  }