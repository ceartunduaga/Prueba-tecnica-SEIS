// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  configFirebase :{
    apiKey: "AIzaSyDn45gByMxpoQM3RoYPfshQQvAv52zcTbo",
    authDomain: "productos-123.firebaseapp.com",
    databaseURL: "https://productos-123.firebaseio.com",
    projectId: "productos-123",
    storageBucket: "productos-123.appspot.com",
    messagingSenderId: "674012136572",
    appId: "1:674012136572:web:c4d538bc995f1c5afbb5f9",
    measurementId: "G-VLV7RFHG8H"
  }
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
